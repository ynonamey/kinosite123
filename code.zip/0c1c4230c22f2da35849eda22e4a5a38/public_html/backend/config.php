<?php
//define("DB_HOST","MySQL-8.0");
//define("DB_USER", "root");
//define("DB_PASSWORD", "");
//define("DB_NAME", "Kino");


define("DB_HOST","localhost");
define("DB_USER", "y90672xk_itskino");
define("DB_PASSWORD", 'svoikino268!');
define("DB_NAME", "y90672xk_itskino");
