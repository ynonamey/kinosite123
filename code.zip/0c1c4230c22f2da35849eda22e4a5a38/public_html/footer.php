<footer>
</footer>
</div> 
<script src="script/script.js"></script>
</body>
</html>